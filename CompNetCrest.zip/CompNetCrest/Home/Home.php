<?php
	error_reporting(E_ERROR | E_PARSE);
	$conn=mysqli_connect('localhost',"root","","compnet_crest");
	//echo("Database connected<br>");

	$fstn2=$_REQUEST['fstn'];
	$lstn2=$_REQUEST['lstn'];
	$email2=$_REQUEST['email'];
	$phone=$_REQUEST['phone'];
	$dd2=$_REQUEST['dd'];
	$mm2=$_REQUEST['mm'];
	$yyyy2=$_REQUEST['yyyy'];
	$question2=$_REQUEST['question'];
	$security2=$_REQUEST['security'];
	$uname2=$_REQUEST['uname'];
	$pass2=$_REQUEST['powrd'];

	if(isset($_REQUEST['nextBtn1']))
	{
		mysqli_query($conn,"INSERT INTO 
		rej(fstn3,lstn3,email3,phone3,dd3,mm3,yyyy3,question3,security3,uname3,pass3)VALUES ('$fstn2','$lstn2','$email2','$phone','$dd2','$mm2','$yyyy2','$question2','$security2','$uname2','$pass2') ");
		/*if(mysqli_affected_rows($conn)>0)
		{
			echo("Data feeded...!");
		}
		else
		{
			echo("Data Not feeded...!");
			echo mysqli_error($conn);
		}*/
	}


if(isset($_POST['loginl']))
    {   /*Value Received From User Login*/
        $useremail=$_POST['unaml'];
        $userpassword= ($_POST['passl']);

       // $userpassword= md5($_POST['TxtPassword']);//md5 function is used to encrypt normal data in secured      
                                                                                                //encrypted form
        /*Value Received From Database*/
        $query2 = "SELECT uname3,pass3 FROM `rej`";
        $result = mysqli_query($conn, $query2);
        while ($row1= mysqli_fetch_array($result))
        {
            $DBemail=$row1["uname3"];
            $DBpassword=$row1["pass3"];
            /*Match The Record Filled by User and Database*/
            if($useremail==$DBemail && $userpassword==$DBpassword)
            {
                /*Code to Response the Page*/
                
	 	//header("Location: http://www.example.com/page.php");
		header("Location: fulltab.php");
		//onclick="location='somepage.html'”
				exit;
            }
			else{echo("DATA wrong");}
        }
    }

?>

<!doctype html>
<html>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../../css/style.css">
<title>Home</title>	
</head>

<body onload="openNav()">                         
	<header>
		<div id="container">
			<canvas id="stats"></canvas>
		</div>

		<form name="loginform" class="form1" id="loginform" method="post"> <!--#333344-->
			<div style="float: left;">
				<label>Username:</label>
				<input type="text" id="unaml1" name="unaml" class="email" autofocus onKeyPress="enterevent1()" required>
			</div>
			
			
			<div style="float: left;margin-left: 10px;">
				<label>Password:</label>
				<input type="password" id="passl1" name="passl" class="email" onKeyPress="enterevent2()" required>
			</div>
			

			
			
			<div style="float: left;margin-left: 10px;outline: none">
				<button id="loginl1" class="btnlogin" name="loginl">
					<span>Login</span>
				</button>
			</div>
			
			
			<div style="float: left;z-index: 1;margin-top: 40px;position: absolute;right: 142px;">
				<a href="../Forget/forget.php" style="color: white">Forgot Password?</a>
			</div>
			
		</form>		
	</header>
		
		
	<!--<span style="font-size:30px;cursor:pointer;float: right" onclick="openNav()">&#9776; open</span>-->
<div  style="float: left;width: 10px">
	<img src="KirsNewProjectImg.png" alt="CompNet Crest" style="width: 900px;height: 550px">
</div>
		
		
<div id="myNav" class="overlay">
<!--<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>-->
	<div>
		<form id="regForm" method="post" action="#" name="regForm">
  			<h1>Register</h1>				
     										<!-- One "tab" for each step in the form: -->
  			<div class="tab">Name:
    			<p>
				<input style="font-family:DigifaceWide;"
					   id="fstn1" 
					   placeholder="First name..."
					   oninput="this.className = ''" 
					   name="fstn" 
					   required onKeyPress="enterevent3()">
				</p>
				
				<p>
				<input id="lstn1" style="font-family:DigifaceWide;" 
					   placeholder="Last name..."
					   oninput="this.className = ''" 
					   name="lstn" 
					   required onKeyPress="enterevent4()">
				</p>
  			</div>
					
					
			<div class="tab">Contact Info:
				<p>
				<input type="email" style="font-family:DigifaceWide;" 
					   id="email1"
					   placeholder="E-mail..." 
					   oninput="this.className = ''" 
					   name="email" 
					   required onKeyPress="enterevent5()">
				</p>
				
				<p>
				<input type="number" style="font-family:DigifaceWide;"
					   id="phone1"
					   name="phone"
					   placeholder="Phone..."
					   oninput="this.className = ''"
					   required onKeyPress="enterevent6()">
				</p>
			</div>
					
					
			<div class="tab">Birthday:
				<p>
				<input type="number" style="font-family:DigifaceWide;"
					   id="dd1" name="dd"
					   placeholder="dd"
					   oninput="this.className = ''"
					   required onKeyPress="enterevent7()">
				</p>
				
				<p>
				<input type="number" style="font-family:DigifaceWide;"
					   id="mm1" name="mm"
					   placeholder="mm"
					   oninput="this.className = ''"
					   required onKeyPress="enterevent8()">
				</p>
				
				<p>
				<input type="number" style="font-family:DigifaceWide;"
					   id="yyyy1"
					   placeholder="yyyy"
					   oninput="this.className = ''"
					   name="yyyy" required onKeyPress="enterevent9()">
				</p>
			</div>
					
					
			<div class="tab">Security Question
				<select style="height: 30px;" required name="question" onKeyPress="enterevent10()">
					<option value="Choose Your Security Question.">Choose Your Security Question.</option>
					  <option value="Favorit Place.">Favorit Place.</option>
					  <option value="Favorit Programming Language.">Favorit Programming Language.</option>
					  <option value="Your favorit MNC Company.">Your favorit MNC Company.</option>
					  <option value="Your favorit Brand.">Your favorit Brand.</option>
					  <option value="Place where you Born.">Place where you Born.</option>
					  <option value="Childhood friend Name.">Childhood friend Name.</option>
				</select>
				
				<p>
				<input type="text" style="font-family:DigifaceWide;"
					   placeholder="Security Answer"
					   name="security" 
					   id="security1" 
					   oninput="this.className = ''" 
					   required onKeyPress="enterevent11()"></p>
			</div>
			
				
			<div class="tab">Login Info:
				<p>
				<input type="text" style="font-family:DigifaceWide;"
					   id="uname1"
					   placeholder="Username..." 
					   oninput="this.className = ''" 
					   name="uname" 
					   required onKeyPress="enterevent12()">
				</p>
				
				<p>
				<input placeholder="Password..." style="font-family:DigifaceWide;"
					   oninput="this.className = ''" 
					   onFocus="function()" 
					   name="powrd" 
					   type="password"
					   id="pass1" 
					   pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
					   title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" 
					   required onKeyPress="enterevent13()">
				</p>
				
				<p>
				<input placeholder="Confirm Password..." style="font-family:DigifaceWide;"
					   oninput="this.className = ''" 	  
					   name="pwor" 
					   type="password"
					   id="passCon" 
					   required onKeyPress="enterevent14()">
				</p>

					  <div id="message">
				  		<h3>Password must contain the following:</h3>
						<p id="letter" class="invalidid">A <b>lowercase</b> letter</p>
						<p id="capital" class="invalidid">A <b>capital (uppercase)</b> letter</p>
						<p id="number" class="invalidid">A <b>number</b></p>
						<p id="length" class="invalidid">Minimum <b>8 characters</b></p>
					  </div>
			</div>
			
<!-------------------------next and previous button-------------------------------------------------->
			  <div style="overflow:auto;">
				<div style="float:right;">
				  <button style="font-family:DigifaceWide;"
						  type="button" 
						  id="prevBtn" 
						  name="prevBtn1" onclick="nextPrev(-1)">Previous
				  </button>
				  <button type="submit" 
						  id="nextBtn" 
						  style="font-family:DigifaceWide;" 
						  name="nextBtn1" onclick="nextPrev(1);validate()">Next
				  </button>
				</div>
			  </div>


<!------------------------- Circles which indicates the steps of the form: ---------------------------------------------------->
			  <div style="text-align:center;margin-top:40px;">
				<span class="step"></span>
				<span class="step"></span>
				<span class="step"></span>
				<span class="step"></span>
				<span class="step"></span>
			  </div>
		</form>
	</div>
</div>
	
<!-------------------------------------------footer------------------------------------------->
	<footer>
		<div class="abc">
			<h3>Contact Us</h3>
			<form >
				<table style="color: darkcyan">
					<tr>
						<td>Mobile No. :-</td>
						<td> +91-2221110000</td>
					</tr>
					<tr>
						<td>Email ID :-</td>
						<td>xyz123@aol.com</td>
					</tr>
					<tr>
						<td>Address :-</td>
						<td>National Highway 31,</td>
					</tr>
					<tr>
						<td></td>
						<td>Near Dark Banglow,</td>
					</tr>
					<tr>
						<td></td>
						<td>Barh, Bihar 803213</td>
					</tr>
				</table>
			</form>
		</div>
<!-----------------------------About-------------------------------------------------->	
		<div style="position: absolute;left: 55%;margin-top: 20px">
			<h3>About</h3>
			<div style="float: left">
				<img src="316688.jpg" width="100px" height="100px">
			</div>
			<div style="float: left;margin-left: 30px;">
				kdjh jhsdl djhsl jdlsb dhsdkfk jsjdhfls <br>
				jbvlsdjsl ljsjls ldnlssl sljlsm lsdns<br>
				sgkdsoesb jhdhvsb kjbds jdbdo bjjdbjsjs<br>
				khgkskjn jdbksjs<br>
			</div>
		</div>
<!-------------------vertical line=----------------------------------------->
		<div style="border-left: 3px solid red;height: 160px;margin-left: 50%;margin-top: 20px"></div>
<!---------------Social Icon---------------------------------------------------------->	
		<div class="icon">
			Follow Us:-
			<a href="#" class="fa fa-facebook"></a>
			<a href="#" class="fa fa-google"></a>
			<a href="#" class="fa fa-youtube"></a>
			<a href="#" class="fa fa-instagram"></a>
			<a href="#" class="fa fa-android"></a>
		</div>
<!---------------------------copyright------------------------------------>		
		<div style="margin-left: 38%;margin-top: -20px">
		&copy;<i>COPYRIGHT_</i>CompNet Crest 2018.<br>
		</div>
		
	</footer>
	
<!-----------------30k particals effect ------------------------------------------>
	<script src="effect.js"></script>
	
	<script>
		
		
		
		
		function openNav() {
    		document.getElementById("myNav").style.width = "32%";
		}

/*function closeNav() {
    document.getElementById("myNav").style.width = "0%";
}*/
		
		var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the crurrent tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  //... and run a function that will display the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class on the current step:
  x[n].className += " active";
}
		//passward validate with given format
		var myInput = document.getElementById("pass1");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
    document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
    document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalidid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalidid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalidid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalidid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalidid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalidid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalidid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalidid");
  }
}
		
		
	//to conferm password 		
		function validate()
		{
			var pass = document.getElementById("pass").value;
			var confirmpass = document.getElementById("passCon").value;
			
			if(pass != confirmpass)
				{
					alert("Password do not match");
					return false;
				}
			return true;
		}
		
		
		
		//enter Event
		function enterevent1()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.loginform.passl.focus();
					}
			}
		function enterevent2()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.loginform.loginl.focus();
					}
			}
			function enterevent3()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.regForm.lstn.focus();
					}
			}
			function enterevent4()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.regForm.nextBtn.focus();
					}
			}
			function enterevent5()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.regForm.phone.focus();
					}
			}
			function enterevent6()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.regForm.nextBtn.focus();
					}
			}
			function enterevent7()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.regForm.mm.focus();
					}
			}
			function enterevent8()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.regForm.yyyy.focus();
					}
			}
			function enterevent9()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.regForm.nextBtn.focus();
					}
			}
			function enterevent10()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.regForm.question.focus();
					}
			}
			function enterevent11()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.regForm.nextBtn.focus();
					}
			}
			function enterevent12()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.regForm.powrd.focus();
					}
			}
			function enterevent13()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.regForm.pwor.focus();
					}
			}
			function enterevent14()
			{
				var x=event.keyCode||event.which;
				if(x===13)
					{
						event.preventDefault();
						document.regForm.nextBtn1.focus();
					}
			}
</script>
</body>
</html>
