<?php
error_reporting(E_ERROR | E_PARSE);
$conn=mysqli_connect('localhost',"root","","compnet_crest");
echo"Database Connected","<br>";

$fstn2=$_REQUEST['fstn'];
$lstn2=$_REQUEST['lstn'];
$email2=$_REQUEST['email'];
$phone2=$_REQUEST['phone'];
$dd2=$_REQUEST['dd'];
$mm2=$_REQUEST['mm'];
$yyyy2=$_REQUEST['yyyy'];
$uname2=$_REQUEST['uname'];
$pass2=$_REQUEST['pass'];


/****************************SAVE_DATA****************************/

if(isset($_REQUEST['nextBtn1']))
{

	mysqli_query($conn,"INSERT INTO
				rej(fstn3,lstn3,email3,phone3,dd3,mm3,yyyy3,uname3,pass3) VALUES('$fstn2','$lstn2','$email2','$phone2','$dd2','$mm2','$yyyy2','$uname2','$pass2')");
	if(mysqli_affected_rows($conn)>0)
	{
		echo "<p>Data Feeded.</p>";	
	}
	else
	{
		echo"Data Not Feed.<br />";	
		echo mysqli_error($conn);
	}
}
?>
<!doctype html>
<html>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/style.css">
		<title>Home</title>	
	</head>

<body onload="openNav()">                         
	<div>
	<header>
		<div class="heddiv">    <!--#333344-->
			<table class="tablee">
				<tr><td>UserName</td>
					<td>:</td>
					<td>
						<input id="unaml1" class="email"
							   type="text" 
							   placeholder="Email/UserName"
							   autocomplete="on" 
							   autofocus required name="unaml">
					</td>
					<td>Password</td>
					<td>:</td>
					<td>
						<input id="passl1" class="email" 
							   type="password" 
							   placeholder="Password" 
							   required
							   name="passl">
					</td>
					<td>
						<button id="loginbtn1" 
								class="btnlogin" 
								name="loginl">
							<span>Login</span>
						</button>
					</td>
				</tr>
			</table>
		</div>
		
		<div style="float: right;margin-top: -60px;color: white;margin-right: 142px">
			<a href="#" style="color: white">Forgot Password?</a>
		</div>
	</header>
		
		
	<!--<span style="font-size:30px;cursor:pointer;float: right" onclick="openNav()">&#9776; open</span>-->
	
		
		
			<div  style="float: left;width: 10px">
			<img src="KirsNewProjectImg.png" alt="CompNet Crest" style="width: 900px;height: 550px">
			</div>
		
		
		
		<div id="myNav" class="overlay">
			
				<!--<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>-->

		<div>
			<form id="regForm" method="post" action="#">
  <h1>Register:</h1>
  <!-- One "tab" for each step in the form: -->
  <div class="tab">Name:
    <p>
		<input id="fstn1" 
			  placeholder="First name..."
			  oninput="this.className = ''" 
			  name="fstn" required>
	  </p>
    <p>
		<input id="lstn1" 
			  placeholder="Last name..."
			  oninput="this.className = ''" 
			  name="lstn" required>
	  </p>
  </div>
  <div class="tab">Contact Info:
    <p>
		<input id="email1"
			  type="email" 
			  placeholder="E-mail..." 
			  oninput="this.className = ''" 
			  name="email" required>
	  </p>
    <p>
		<input id="phone1"
			  type="number"
			  placeholder="Phone..."
			  oninput="this.className = ''"
			  name="phone" required>
	  </p>
  </div>
  <div class="tab">Birthday:
    <p>
		<input type="number"
			  id="dd1" placeholder="dd"
			  oninput="this.className = ''"
			  name="dd" required>
	  </p>
    <p>
		<input type="number"
			  id="mm1" placeholder="mm"
			  oninput="this.className = ''"
			  name="mm" required>
	  </p>
    <p>
		<input type="number"
			  id="yyyy1"
			  placeholder="yyyy"
			  oninput="this.className = ''"
			  name="yyyy" required>
	  </p>
  </div>
  <div class="tab">Login Info:
    <p><input type="text" id="uname1"
			  placeholder="Username..." 
			  oninput="this.className = ''" 
			  name="uname" required>
	</p>
    <p>
		<input placeholder="Password..." 
			  oninput="this.className = ''" 
			  onFocus="function()" name="pass" 
			  type="password" id="pass1" 
			  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
			  title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
	  </p>
	<p>
		<input placeholder="Confirm Password..."
			  oninput="this.className = ''" 
			  name="pwor" type="password"
			  id="passCon" required>
	  </p>
	  <div id="message">
  <h3>Password must contain the following:</h3>
	<p id="letter" class="invalidid">A <b>lowercase</b> letter</p>
	<p id="capital" class="invalidid">A <b>capital (uppercase)</b> letter</p>
	<p id="number" class="invalidid">A <b>number</b></p>
	<p id="length" class="invalidid">Minimum <b>8 characters</b></p>
</div>
  </div>
  <div style="overflow:auto;">
    <div style="float:right;">
      <button type="button" id="prevBtn" name="prevBtn1" onclick="nextPrev(-1)">Previous</button>
      <button type="submit" id="nextBtn"  name="nextBtn1" onclick="nextPrev(1);validate()">Next</button>
    </div>
  </div>
  <!-- Circles which indicates the steps of the form: -->
  <div style="text-align:center;margin-top:40px;">
    <span class="step"></span>
    <span class="step"></span>
    <span class="step"></span>
    <span class="step"></span>
  </div>
</form>
		</div>
		</div>
	
	<div class="foot">
		&copy;<i>COPYRIGHT_</i>CompNet Crest 2018.
		<div style="float: right;margin-top: -35px">
			<a href="#" class="fa fa-facebook"></a>
			<a href="#" class="fa fa-google"></a>
			<a href="#" class="fa fa-youtube"></a>
			<a href="#" class="fa fa-instagram"></a>
			<a href="#" class="fa fa-android"></a>
		</div>
	</div>
	</div>
	
	
	
	
	
	<script>
		
		function openNav() {
    		document.getElementById("myNav").style.width = "32%";
		}

/*function closeNav() {
    document.getElementById("myNav").style.width = "0%";
}*/
		
		var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the crurrent tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  //... and run a function that will display the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class on the current step:
  x[n].className += " active";
}
		//passward validate with given format
		var myInput = document.getElementById("pass1");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
    document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
    document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalidid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalidid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalidid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalidid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalidid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalidid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalidid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalidid");
  }
}
		
		
	//to conferm password 		
		function validate()
		{
			var pass = document.getElementById("pass").value;
			var confirmpass = document.getElementById("passCon").value;
			
			if(pass != confirmpass)
				{
					alert("Password do not match");
					return false;
				}
			return true;
		}
		
</script>
</body>
</html>
