<?php
error_reporting(E_ERROR | E_PARSE);
	$conn=mysqli_connect('localhost',"root","","compnet_crest");
	//echo("Database connected<br>");
//echo("Database Connect...!");

?>

<?php
if(isset($_POST['sub'])){
	echo("hello");
	$uname11=$_REQUEST['quest'];
	$unamans11=$_REQUEST['ans'];

echo($unamans11);
echo($uname11);

/*Value Received From Database*/
        $query2 = "SELECT question3,security3 FROM `rej`";
        $result = mysqli_query($conn, $query2);

while ($row1= mysqli_fetch_array($result))
        {
            $DBquestion=$row1["question3"];
            $DBanswer=$row1["security3"];
            /*Match The Record Filled by User and Database*/
            if($uname11==$DBquestion && $unamans11==$DBanswer)
            {
                /*Code to Response the Page*/
                
	 	//header("Location: http://www.example.com/page.php");
		header("Location: Password Reset/passwordreset.html");
		//onclick="location='somepage.html'”
				exit;
            }
			else{echo("DATA wrong");}
        }
	
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../../css/forget.css">
	<link rel="stylesheet" href="style2.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body onload="document.getElementById('id01').style.display='block'" style="height: 100%;margin: 0;">
	<div id="particles-js"></div>
	<div id="id01" class="modal">
  		<form class="modal-content animate" action="#" method="post">
			<div class="imgcontainer">
			  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
			  <img src="../../images/Robot-PNG-HD.png" alt="Avatar" class="avatar">
			</div>

			<div class="containerxyz">
			  <label for="uname"><b>Choose Your Security Question.</b></label>
				  <select style="height: 30px;background: darkgray;" name="quest">
						<option>Choose Your Security Question</option>
						<option value="Favorit Place.">Favorit Place.</option>
						<option value="Favorit Programming Language.">Favorit Programming Language.</option>
						<option value="Your favorit MNC Company.">Your favorit MNC Company.</option>
						<option value="Your favorit Brand.">Your favorit Brand.</option>
						<option value="Place where you Born.">Place where you Born.</option>
						<option value="Childhood friend Name.">Childhood friend Name.</option>
				  </select>
			  <input type="text" placeholder="Security Answer" name="ans" required>

			  <!--<label for="psw"><b>Password</b></label>
			  <input type="password" placeholder="Enter Password" name="psw" required>-->

			  <button type="submit" name="sub">Submit</button>
			 <!-- <label>
				<input type="checkbox" checked="checked" name="remember"> Remember me
			  </label>-->
			</div>

			<div class="container">
			  <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
			<!--  <span class="psw">Forgot <a href="#">password?</a></span>-->
			</div>
  		</form>
	</div>
	<!-------------------------------------------footer------------------------------------------->
	<footer>
		<div class="abc">
			<h3>Contact Us</h3>
			<form >
				<table style="color: darkcyan">
					<tr>
						<td>Mobile No. :-</td>
						<td> +91-2221110000</td>
					</tr>
					<tr>
						<td>Email ID :-</td>
						<td>xyz123@aol.com</td>
					</tr>
					<tr>
						<td>Address :-</td>
						<td>National Highway 31,</td>
					</tr>
					<tr>
						<td></td>
						<td>Near Dark Banglow,</td>
					</tr>
					<tr>
						<td></td>
						<td>Barh, Bihar 803213</td>
					</tr>
				</table>
			</form>
		</div>
<!-----------------------------About-------------------------------------------------->	
		<div style="position: absolute;left: 55%;margin-top: 20px">
			<h3>About</h3>
			<div style="float: left">
				<img src="../../316688.jpg" width="100px" height="100px">
			</div>
			<div style="float: left;margin-left: 30px;">
				kdjh jhsdl djhsl jdlsb dhsdkfk jsjdhfls <br>
				jbvlsdjsl ljsjls ldnlssl sljlsm lsdns<br>
				sgkdsoesb jhdhvsb kjbds jdbdo bjjdbjsjs<br>
				khgkskjn jdbksjs<br>
			</div>
		</div>
<!-------------------vertical line=----------------------------------------->
		<div style="border-left: 3px solid red;height: 160px;margin-left: 50%;margin-top: 20px"></div>
<!---------------Social Icon---------------------------------------------------------->	
		<div class="icon">
			Follow Us:-
			<a href="#" class="fa fa-facebook"></a>
			<a href="#" class="fa fa-google"></a>
			<a href="#" class="fa fa-youtube"></a>
			<a href="#" class="fa fa-instagram"></a>
			<a href="#" class="fa fa-android"></a>
		</div>
<!---------------------------copyright------------------------------------>		
		<div style="margin-left: 38%;margin-top: -20px">
		&copy;<i>COPYRIGHT_</i>CompNet Crest 2018.<br>
		</div>
		
	</footer>

<script src="particles.js"></script>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}



	
			particlesJS.load('particles-js','particles.json', 
			function(){
				 console.log('particles.json loaded.....')
			}
			)
		
</script>

</body>
</html>
