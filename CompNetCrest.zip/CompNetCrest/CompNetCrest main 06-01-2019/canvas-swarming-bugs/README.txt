A Pen created at CodePen.io. You can find this one at https://codepen.io/jackrugile/pen/swLat.

 The swarming bugs will latch on to and eat any food that gets within range. Click the screen to create more food. Using the lovely [Sketch.js](http://soulwire.github.com/sketch.js/) once again!