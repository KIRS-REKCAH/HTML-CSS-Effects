<?php
error_reporting(E_ERROR | E_PARSE);
if(isset($_POST['logbtn']))
    {   /*Value Received From User Login*/
        $useremail=$_POST['unam'];
        $userpassword= ($_POST['psw']);

       // $userpassword= md5($_POST['TxtPassword']);//md5 function is used to encrypt normal data in secured      
                                                                                                //encrypted form
        /*Value Received From Database*/
        $query2 = "SELECT uname3,pass3 FROM `rej`";
        $result = mysqli_query($conn, $query2);
        while ($row1= mysqli_fetch_array($result))
        {
            $DBemail=$row1["uname3"];
            $DBpassword=$row1["pass3"];
            /*Match The Record Filled by User and Database*/
            if($useremail==$DBemail && $userpassword==$DBpassword)
            {
                /*Code to Response the Page*/
                
	 	//header("Location: http://www.example.com/page.php");
		header("Location: ../fulltab/fulltab.php");
		//onclick="location='somepage.html'”
				exit;
            }
			else{echo("DATA wrong");}
        }
    }

?>
<!doctype html>
<html>
	<head>
		<link rel="shortcut icon" type="image/png" href="#">
		<link rel="stylesheet" href="../../css/congrates.css">
	</head>

<body>
	<div id="particles-js"></div>
		<center>
			<div class="div3">
				Congratulation......!
			<p class="pp2">You Have Succesfully Submitted Your Detail.<br>
			   	Now You Log Into Your Account.
			</p>
			</div>
			<div class="div4">
				<button onclick="document.getElementById('id01').style.display='block'" class="btn">Login</button>
			</div>
		</center>
		
		
<div id="id01" class="modal">
	<form class="modal-content animate" id="loginc" name="loginc" method="post" action="../fulltab/fulltab.php">
    	<div class="imgcontainer">
      		<span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      		<img src="../../images/Robot-PNG-HD.png" alt="CompNet Crest" class="avatar">
    	</div>

    	<div class="container">
      		<label><b>Username</b></label>
      		<input type="text" placeholder="Enter Username" name="unam" required onKeyPress="enterevent()" autofocus>
      		<label><b>Password</b></label>
      		<input type="password" placeholder="Enter Password" name="psw" required onKeyPress="enterevent1()">
      		<button type="submit" class="id34" id="logbtn" name="logbtn">Login</button>
      		<input type="checkbox" checked="checked"> Remember me
   	 	</div>

		<div class="container">
		  <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
		  <span class="psw">Forget <a href="forget.html">password?</a></span>
		</div>
  	</form>
</div>
		
		

	<footer style="text-align: center">&copy;<i>COPYRIGHT_</i>CompNet Crest 2018.</footer>

		
	
<!---------------------------------------------------particals joining effect ------------------------------------------->
	<script src="particles.js"></script>
	<script>particlesJS.load('particles-js','particles.json', 
			function(){
				 console.log('particles.json loaded.....')
			}
			)</script>
		<script>
// Get the modal7
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

//enter event..........

function enterevent()
		{
			var x=event.keyCode||event.which;
			if(x===13)
			{
				event.preventDefault();
				document.loginc.psw.focus();
			}
		}
		
function enterevent1()
		{
			varx=event.keyCode||Event.which;
			if(x===13)
			{
				event.preventDefault();
				document.loginc.logbtn.focus();
			}
		}		
</script>
</body>
</html>
