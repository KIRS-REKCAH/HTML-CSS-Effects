<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
		* {box-sizing: border-box;font-family:DigifaceWide;}
/******************Set height of body and the document to 100% **********************/
	body, html
		{
			height: 100%;
			margin: 0;
			font-family:DigifaceWide;
		}

/************************************Style tab links******************************/
.tablink {
    background-color:darkcyan;
    color: black;
    float: left;
    border:none;
    outline:none;
    cursor:pointer;
    padding: 14px 16px;
    font-size: 17px;
    width: 25%;
}

.tablink:hover {
    background-color:darkslategray;  /*#777*/
}

/* Style the tab content (and add height:100% for full page content) */
.tabcontent {
    color: white;
    padding: 100px 20px;
    height: 100%;
}
	.openBtn {
    background: #f1f1f1;
    border: none;
    padding: 10px 15px;
    font-size: 20px;
    cursor: pointer;
}

.openBtn:hover {
    background: #bbb;
}

#sticky-social {
   right: 0;
   position: fixed;
   top: 100px;
}

#sticky-social a {
   background: #333;
   color: #fff;
   display: block;
   height: 40px;
   font: 16px ;
   line-height: 40px;
   position: relative;
   text-align: center;
   width: 40px;
	border-bottom-right-radius: 10px;
	border-top-left-radius: 10px;
}

#sticky-social a:hover span {
   right: 100%;
}

#sticky-social a span {
   line-height: 40px;
   right: -120px;
   position: absolute;
   text-align:center;
   width:120px;
	border-radius: 50%;
}

#sticky-social a[class*="power-off"],
#sticky-social a[class*="power-off"]:hover,
#sticky-social a[class*="power-off"] span { background: #F01E93; }	
	
#sticky-social a[class*="facebook"],
#sticky-social a[class*="facebook"]:hover,
#sticky-social a[class*="facebook"] span { background: #3b5998; }

#sticky-social a[class*="twitter"],
#sticky-social a[class*="twitter"]:hover,
#sticky-social a[class*="twitter"] span { background: #00aced; }

#sticky-social a[class*="google-plus"],
#sticky-social a[class*="google-plus"]:hover,
#sticky-social a[class*="google-plus"] span { background: #dd4b39; }	

#sticky-social a[class*="home"],
#sticky-social a[class*="home"]:hover,
#sticky-social a[class*="home"] span { background-color: #0F6C51; }	

#sticky-social a[class*="male"],
#sticky-social a[class*="male"]:hover,
#sticky-social a[class*="male"] span { background: #517fa4; }	

#sticky-social a[class*="phone"],
#sticky-social a[class*="phone"]:hover,
#sticky-social a[class*="phone"] span { background-color: slategray; }	

#sticky-social a[class*="search"],
#sticky-social a[class*="search"]:hover,
#sticky-social a[class*="search"] span { background-color:#2E2828; }
	
#sticky-social a[class*="play-circle"],
#sticky-social a[class*="play-circle"]:hover,
#sticky-social a[class*="play-circle"] span { background-color: darkgray; }			

#sticky-social a[class*="forward"],
#sticky-social a[class*="forward"]:hover,
#sticky-social a[class*="forward"] span { background-color:#437873; }	

#sticky-social a[class*="backward"],
#sticky-social a[class*="backward"]:hover,
#sticky-social a[class*="backward"] span { background-color: gray; }	


a { 
   text-decoration: none;
}

ul {
   list-style: none;
   margin: 0;
   padding: 0;
}

footer{
		background-color: black;
		top: 100%;
		position: absolute;
		width: 100%;
		height: 36%;
		color: darkcyan;	
	}
.abc
	{
		position: absolute;
		padding: 20px;
	}
		
#Home {background-color:#6AB392;}
#News {background-color: #6AB392;}
#Contact {background-color: #6AB392;}
#About {background-color: #6AB392;}

	.overlay1 {
    height: 100%;
    width: 100%;
    display: none;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: rgb(0,0,0);
    background-color: rgba(0,0,0, 0.9);
}

.overlay1-content {
    position: relative;
    top: 46%;
    width: 80%;
    text-align: center;
    margin-top: 30px;
    margin: auto;
}

.overlay1 .closebtn {
    position: absolute;
    top: 80%;
    right: 45%;
    font-size: 60px;
    cursor: pointer;
    color: red;
}

.overlay1 .closebtn:hover {
    color:#09309A;
}

.overlay1 input[type=text] {
	 box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
     background-image: url('searchicon.png');
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
    background-color: white; 
    font-size: 17px;
    float: left;
    width: 15%;
    background:#ccc;
}

.overlay1 input[type=text]:hover {
    background: #f1f1f1;
	width: 100%;
}

/*.overlay1 button {
    float: left;
    width: 20%;
    padding: 15px;
    background: #ddd;
    font-size: 17px;
    border: none;
    cursor: pointer;
}*/

.overlay1 button:hover {
    background: #bbb;
}

</style>
</head>
<body>
	<button class="tablink" onclick="openPage('Home', this, '#6AB392')" id="defaultOpen">Tutorials</button>
	<button class="tablink" onclick="openPage('News', this, '#6AB392')">Project</button>
	<button class="tablink" onclick="openPage('Contact', this, '#6AB392')">Hardware Issuse</button>
	<button class="tablink" onclick="openPage('About', this, '#6AB392')">Miscellaneous</button>
	
	<div id="Home" class="tabcontent">
 		<object width="100%" height="135%" data="../ProgramPlushTheoryList/programplushtheorylist.html"></object>
		<aside id="sticky-social">
			<ul>
				<li><a href="../fulltab/fulltab.php" class="fa fa-home" target="_blank"><span>Home</span></a></li>
				<li><a href="#" class="fa fa-power-off" taget="_blank"><span>Logout</span></a></li>
				<li><a href="#" class="fa fa-forward" taget="_blank"><span>Forward</span></a></li>
				<li><a href="#" class="fa fa-backward" target="_blank"><span>Backward</span></a></li>
				<li><a href="#" class="fa fa-search" onclick="openSearch()"><span>Search</span></a></li>
				<li><a href="../canvas-swarming-bugs/index.html" class="fa fa-play-circle" target="_blank"><span>Play</span></a></li>
				<li><a href="#" class="fa fa-phone" target="_blank"><span>Contact</span></a></li>
				<li><a href="#" class="fa fa-male" target="_blank"><span>About</span></a></li>
				<li><a href="#" class="fa fa-facebook" target="_blank"><span>Facebook</span></a></li>
				<li><a href="#" class="fa fa-twitter-square -twitter" target="_blank"><span>Twitter</span></a></li>
				<li><a href="#" class="fa fa-google-plus" target="_blank"><span>Google+</span></a></li>
			</ul>
		</aside>
	</div>
	
<div id="myOverlay" class="overlay1">
  <span class="closebtn" onclick="closeSearch()" title="Close Overlay">×</span>
  <div class="overlay1-content">
	  <input type="image" src="search.png" height="25px" width="25px" style="left: 1%;position: absolute;margin-top: 10px">
	  <input type="text" placeholder="Search.." name="search" autofocus>
      <!--<button type="submit"><i class="fa fa-search"></i></button>-->
		<h2 style="position: fixed;margin-left: 35%;margin-top: -10%;color: white">CompNet Crest<br></h2><h4 style="position: fixed;margin-left: 32%;margin-top: -7%;color: white">Computer+Network=CompNet</h4>
    
  </div>
</div>
	
	<div id="News" class="tabcontent">
  		<object width="100%" height="135%" data="../OnlineOfflineProject/onlineofflineproject.html"></object>
		<aside id="sticky-social">
			<ul>
				<li><a href="../fulltab/fulltab.php" class="fa fa-home" target="_blank"><span>Home</span></a></li>
				<li><a href="#" class="fa fa-power-off" taget="_blank"><span>Logout</span></a></li>
				<li><a href="#" class="fa fa-forward" taget="_blank"><span>Forward</span></a></li>
				<li><a href="#" class="fa fa-backward" target="_blank"><span>Backward</span></a></li>
				<li><a href="#" class="fa fa-search" onclick="openSearch()"><span>Search</span></a></li>
				<li><a href="#" class="fa fa-play-circle" target="_blank"><span>Play</span></a></li>
				<li><a href="#" class="fa fa-phone" target="_blank"><span>Contact</span></a></li>
				<li><a href="#" class="fa fa-male" target="_blank"><span>About</span></a></li>
				<li><a href="#" class="fa fa-facebook" target="_blank"><span>Facebook</span></a></li>
				<li><a href="#" class="fa fa-twitter-square -twitter" target="_blank"><span>Twitter</span></a></li>
				<li><a href="#" class="fa fa-google-plus" target="_blank"><span>Google+</span></a></li>
			</ul>
		</aside>
	</div>

<div id="Contact" class="tabcontent">
	<div class="middle">
    	<h1>COMING SOON</h1>
    	<hr>
	  	<p id="demo" style="font-size:30px"></p>
	<aside id="sticky-social">
		<ul>
			<li><a href="../fulltab/fulltab.php" class="fa fa-home" target="_blank"><span>Home</span></a></li>
			<li><a href="#" class="fa fa-power-off" taget="_blank"><span>Logout</span></a></li>
			<li><a href="#" class="fa fa-forward" taget="_blank"><span>Forward</span></a></li>
			<li><a href="#" class="fa fa-backward" target="_blank"><span>Backward</span></a></li>
			<li><a href="#" class="fa fa-search" onclick="openSearch()"><span>Search</span></a></li>
			<li><a href="#" class="fa fa-play-circle" target="_blank"><span>Play</span></a></li>
			<li><a href="#" class="fa fa-phone" target="_blank"><span>Contact</span></a></li>
			<li><a href="#" class="fa fa-male" target="_blank"><span>About</span></a></li>
			<li><a href="#" class="fa fa-facebook" target="_blank"><span>Facebook</span></a></li>
			<li><a href="#" class="fa fa-twitter-square -twitter" target="_blank"><span>Twitter</span></a></li>
			<li><a href="#" class="fa fa-google-plus" target="_blank"><span>Google+</span></a></li>
		</ul>
	</aside>
  </div>
</div>

<div id="About" class="tabcontent">
  <aside id="sticky-social">
		<ul>
			<li><a href="../fulltab/fulltab.php" class="fa fa-home"><span>Home</span></a></li>
			<li><a href="#" class="fa fa-power-off" taget="_blank"><span>Logout</span></a></li>
			<li><a href="#" class="fa fa-forward" taget="_blank"><span>Forward</span></a></li>
			<li><a href="#" class="fa fa-backward" target="_blank"><span>Backward</span></a></li>
			<li><a href="#" class="fa fa-search" onclick="openSearch()"><span>Search</span></a></li>
			<li><a href="#" class="fa fa-play-circle" target="_blank"><span>Play</span></a></li>
			<li><a href="#" class="fa fa-phone" target="_blank"><span>Contact</span></a></li>
			<li><a href="#" class="fa fa-male" target="_blank"><span>About</span></a></li>
			<li><a href="#" class="fa fa-facebook" target="_blank"><span>Facebook</span></a></li>
			<li><a href="#" class="fa fa-twitter-square -twitter" target="_blank"><span>Twitter</span></a></li>
			<li><a href="#" class="fa fa-google-plus" target="_blank"><span>Google+</span></a></li>
		</ul>
	</aside>
</div>
	
	
<!-------------------------Footer------------------------------------>	
<footer>
		<div class="abc">
			<h3>Contact Us</h3>
			<form >
				<table style="color: darkcyan">
					<tr>
						<td>Mobile No. :-</td>
						<td> +91-2221110000</td>
					</tr>
					<tr>
						<td>Email ID :-</td>
						<td>xyz123@aol.com</td>
					</tr>
					<tr>
						<td>Address :-</td>
						<td>National Highway 31,</td>
					</tr>
					<tr>
						<td></td>
						<td>Near Dark Banglow,</td>
					</tr>
					<tr>
						<td></td>
						<td>Barh, Bihar 803213</td>
					</tr>
				</table>
			</form>
		</div>
		<!---------------------------About Section------------------------------------------>
		<div style="position: absolute;left: 55%;margin-top: 20px">
			<h3>About</h3>
			<div style="float: left">
			<img src="316688.jpg" width="100px" height="100px">
			</div>
			<div style="float: left;margin-left: 30px;">
				kdjh jhsdl djhsl jdlsb dhsdkfk jsjdhfls <br>
				jbvlsdjsl ljsjls ldnlssl sljlsm lsdns<br>
				sgkdsoesb jhdhvsb kjbds jdbdo bjjdbjsjs<br>
				khgkskjn jdbksjs<br>
			</div>
		</div>
	<!-----------------vertical line--------------------------------------->
		<div style="border-left: 3px solid red;height: 160px;margin-left: 50%;margin-top: 20px"></div>
	
	<!---------------------------copyright------------------------------------------>
		<div style="margin-left: 41%;margin-top: 46px;">
		&copy;<i>COPYRIGHT_</i>CompNet Crest 2018.<br>
		</div>
		
	</footer>
<script>
	
	

	
	
	
	
function openPage(pageName,elmnt,color) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].style.backgroundColor = "";
    }
    document.getElementById(pageName).style.display = "block";
    elmnt.style.backgroundColor = color;

}
// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
	
	
	
	function openSearch() {
    document.getElementById("myOverlay").style.display = "block";
}

function closeSearch() {
    document.getElementById("myOverlay").style.display = "none";
}
</script>
     
</body>
</html> 
